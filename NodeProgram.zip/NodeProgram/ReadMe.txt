A simple node.js program doing some number/character converting


Menu.js is the main program, run it