module.exports = {
    bytenumbertobits: function (number)
    {
        var numberasbits = '';

        var bitpos = 1;

        for (let i = 0; i < 8; i++) {
            if(number & bitpos)
            {
                numberasbits = '1' + numberasbits;
            }
            else
            {
                numberasbits = '0' + numberasbits;
            }
            bitpos *= 2;
        }

        return numberasbits;
    }
}