const readline = require('readline');
const utils = require('./utils');

var savedchoice = 0;

var bits = utils.bytenumbertobits(65);

console.log("Number 65's bit presentation is " + bits);

texttobits("Hello world")

ask();

function texttobits(text)
{
    var chars = text.split("");

    console.log("Given text is " + chars.length + " characters long.")

    var textasbits = '';

    for (let i = 0; i < chars.length; i++) {

        var number = chars[i].charCodeAt(0);
        var bits = utils.bytenumbertobits(number);
        console.log("Character is " + chars[i] + ". It's ascii code is " + number + ". Bit presentation is " + bits);

        textasbits = bits + textasbits;

    }

    console.log(textasbits);
}

function ask()
{
    let rl = readline.createInterface(
        process.stdin, process.stdout);

    if(savedchoice == 4)
    {
        rl.question('Write text: ', (text) =>
         {

            rl.close();

            texttobits(text);

            savedchoice = 0;
            ask();

        }); 
    }   
    else
    { 

        console.log("(1) hello");
        console.log("(2) open AlfaKalle song");
        console.log("(3) convert text abcdefghijklmnopqrstuwvxyz to bits");
        console.log("(4) write text to be converted to bits");
        console.log("(any other key) quit");

        rl.question('Make your choice: ', (choice) => 
        {

            rl.close();

            console.log('You choce:  ' + choice);

            if(choice > 0 && choice <= 4)
            {
                if(choice == 1)
                {
                    console.log("Hello world");
                }
                else if(choice == 2)
                {
                    require('child_process').exec('start https://www.youtube.com/watch?v=m6QzNdbYmHY');
                }
                else if(choice == 3)
                {           
                    texttobits("abcdefghijklmnopqrstuwvxyz");                   
                }
                else if(choice == 4)
                {
                    savedchoice = choice;          
                }

                ask();
            }
            else
            {
                console.log("Quitting");   
            }     
            
        });

    }
}
